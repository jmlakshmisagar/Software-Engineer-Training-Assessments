package basics;

public enum EnumDemo03 {
	
	RED, GREEN, BLUE;
	
	public static void main(String[] args){
		EnumDemo03 val = EnumDemo03.RED;
		System.out.println(val);
	}
}
